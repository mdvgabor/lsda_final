import os
import io
import boto3
import pandas as pd

import requests_cache
from retry_requests import retry
import openmeteo_requests


# ---------- AWS clients ----------
s3 = boto3.client("s3")


# ---------- Open-Meteo client ----------
def get_openmeteo_client():
    # Lambda can only write to /tmp
    cache_session = requests_cache.CachedSession("/tmp/.cache", expire_after=86400)
    retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
    return openmeteo_requests.Client(session=retry_session)


def get_archive_daily_weather(
    lat,
    lon,
    start_date,
    end_date,
    openmeteo,
    url="https://archive-api.open-meteo.com/v1/archive",
):
    params = {
        "latitude": float(lat),
        "longitude": float(lon),
        "start_date": start_date,
        "end_date": end_date,
        "daily": ["temperature_2m_mean", "sunshine_duration", "precipitation_sum"],
    }

    responses = openmeteo.weather_api(url, params=params)
    response = responses[0]
    daily = response.Daily()

    daily_dates = pd.date_range(
        start=pd.to_datetime(daily.Time(), unit="s", utc=True),
        end=pd.to_datetime(daily.TimeEnd(), unit="s", utc=True),
        freq=pd.Timedelta(seconds=daily.Interval()),
        inclusive="left",
    )

    daily_df = pd.DataFrame(
        {
            "date": daily_dates,
            "temperature_2m_mean": daily.Variables(0).ValuesAsNumpy(),
            "sunshine_duration": daily.Variables(1).ValuesAsNumpy(),
            "precipitation_sum": daily.Variables(2).ValuesAsNumpy(),
            "latitude": float(lat),
            "longitude": float(lon),
        }
    )

    return daily_df


# ---------- S3 helpers ----------
def read_csv_from_s3(bucket: str, key: str) -> pd.DataFrame:
    obj = s3.get_object(Bucket=bucket, Key=key)
    data = obj["Body"].read()
    return pd.read_csv(io.BytesIO(data))


def upload_file_to_s3(local_path: str, bucket: str, key: str) -> None:
    s3.upload_file(Filename=local_path, Bucket=bucket, Key=key)


# ---------- Main Lambda handler ----------
def lambda_handler(event, context):
    """
    Set these Lambda environment variables:
      INPUT_BUCKET, INPUT_KEY
      OUTPUT_BUCKET, OUTPUT_KEY
      START_DATE, END_DATE
      SAMPLE_SIZE
    """

    # ---- env vars ----
    input_bucket = os.environ["INPUT_BUCKET"]
    input_key = os.environ.get("INPUT_KEY", "california_housing.csv")

    output_bucket = os.environ["OUTPUT_BUCKET"]
    output_key = os.environ.get("OUTPUT_KEY", "final_housing_500.csv")

    start_date = os.environ.get("START_DATE", "2025-03-01")
    end_date = os.environ.get("END_DATE", "2025-09-01")

    sample_size = int(os.environ.get("SAMPLE_SIZE", "500"))

    # ---- init openmeteo ----
    openmeteo = get_openmeteo_client()

    # ---- read housing data from S3 ----
    df = read_csv_from_s3(input_bucket, input_key)

    # ---- fill missing total_bedrooms with median ----
    if "total_bedrooms" in df.columns:
        median_bedrooms = df["total_bedrooms"].median()
        df["total_bedrooms"] = df["total_bedrooms"].fillna(median_bedrooms)

    # ---- cap outliers in numeric columns (IQR) ----
    numeric_cols = df.select_dtypes(include="number").columns
    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1

        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR

        df[col] = df[col].clip(lower, upper)

    # ---- stratified sample of size ~ sample_size ----
    # (keeps your original idea but makes sure the sample sizes sum correctly)
    proportions = df["ocean_proximity"].value_counts(normalize=True)
    alloc = (proportions * sample_size).round().astype(int)

    # fix rounding drift so total == sample_size
    drift = sample_size - alloc.sum()
    if drift != 0:
        order = alloc.sort_values(ascending=False).index.tolist()
        step = 1 if drift > 0 else -1
        for i in range(abs(drift)):
            alloc[order[i % len(order)]] += step

    parts = []
    for cat, n in alloc.items():
        if n <= 0:
            continue
        parts.append(df[df["ocean_proximity"] == cat].sample(n=n, random_state=1))

    sampled_df = pd.concat(parts, ignore_index=True)

    # ---- weather fetching for unique lat/lon ----
    unique_locations = sampled_df[["latitude", "longitude"]].drop_duplicates()

    daily_weather_dfs = []
    for _, row in unique_locations.iterrows():
        # optional safety: stop if we're about to time out
        if context.get_remaining_time_in_millis() < 30_000:
            print("Stopping early to avoid timeout.")
            break

        try:
            df_daily = get_archive_daily_weather(
                lat=row["latitude"],
                lon=row["longitude"],
                start_date=start_date,
                end_date=end_date,
                openmeteo=openmeteo,
            )
            daily_weather_dfs.append(df_daily)
        except Exception as e:
            print(f"Failed for lat={row['latitude']}, lon={row['longitude']}: {e}")

    # ---- aggregate weather to yearly per location ----
    if daily_weather_dfs:
        weather_daily_df = pd.concat(daily_weather_dfs, ignore_index=True)
        weather_daily_df["year"] = weather_daily_df["date"].dt.year

        weather_yearly_df = (
            weather_daily_df.groupby(["year", "latitude", "longitude"], as_index=False)
            .agg(
                temperature_2m_mean=("temperature_2m_mean", "mean"),
                sunshine_duration=("sunshine_duration", "sum"),
                precipitation_sum=("precipitation_sum", "sum"),
            )
        )

        # If your window is inside one year, this collapses to one row per lat/lon.
        weather_latest = (
            weather_yearly_df.sort_values("year")
            .drop(columns=["year"])
            .drop_duplicates(subset=["latitude", "longitude"], keep="last")
        )
    else:
        weather_latest = pd.DataFrame(
            columns=[
                "latitude",
                "longitude",
                "temperature_2m_mean",
                "sunshine_duration",
                "precipitation_sum",
            ]
        )

    # ---- merge housing + weather ----
    final_df = sampled_df.merge(
        weather_latest,
        on=["latitude", "longitude"],
        how="left",
    )

    # ---- save to /tmp and upload to S3 ----
    out_path = "/tmp/final_housing_500.csv"
    final_df.to_csv(out_path, index=False)
    upload_file_to_s3(out_path, output_bucket, output_key)

    return {
        "statusCode": 200,
        "rows": int(final_df.shape[0]),
        "output": f"s3://{output_bucket}/{output_key}",
    }